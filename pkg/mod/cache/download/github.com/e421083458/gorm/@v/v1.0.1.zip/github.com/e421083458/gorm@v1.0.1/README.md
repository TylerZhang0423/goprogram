# GORM Log adds context features

> If I want to set up a separate context context for a HTTP session request, You can use this feature.

- Testing steps
- export DEBUG=true
- export LOGCTX=true
- go test -v -run "TestLogger"
